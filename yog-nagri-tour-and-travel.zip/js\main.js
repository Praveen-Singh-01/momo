/**
 * Yog Nagri Tour And Travel (योग नगरी टूर एंड ट्रैवल)
 * Production JavaScript Engine
 * Handles Navigation, Booking Forms, WhatsApp Integrations, Lightbox, Modals & Toast System
 */

(function () {
  'use strict';

  // Constants
  const WHATSAPP_PHONE = '919997999391';
  const DISPLAY_PHONE = '+91 99979 99391';

  // Package Data for Interactive Modal Preview
  const PACKAGES_DATA = {
    'rishikesh-explorer': {
      title: 'Rishikesh Explorer',
      duration: '2 Days / 1 Night',
      category: 'Spiritual & Heritage',
      description: 'Experience both the sacred tranquility and scenic riverside beauty of holy Rishikesh. Includes peaceful Ganga Ghat visits, evening Maha Aarti at Triveni Ghat, Ram Jhula, and an invigorating morning walk to Neer Garh waterfall.',
      highlights: [
        'Evening Maha Aarti with reserved seating assistance at Triveni Ghat',
        'Guided visit to Ram Jhula, Laxman Jhula pedestrian zone & local ashrams',
        'Refreshing nature hike to multi-tiered Neer Garh waterfall',
        'Comfortable air-conditioned local transportation & local driver guide'
      ],
      inclusions: [
        'Dedicated AC Cab for all local sightseeing',
        'Assistance with evening Aarti darshan',
        'Experienced mountain-trained local chauffeur',
        'Toll taxes, parking & fuel charges included'
      ]
    },
    'rishikesh-adventure': {
      title: 'Rishikesh Adventure Tour',
      duration: '3 Days / 2 Nights',
      category: 'Adventure & Camping',
      description: 'An adrenaline-fueled weekend getaway featuring Grade III white-water rafting on the emerald Ganga, cliff jumping, body surfing, luxury Swiss-tent camping in Shivpuri, and starry evening bonfires with barbecue.',
      highlights: [
        '16 Km thrilling river rafting stretch from Shivpuri to Rishikesh with certified masters',
        'Cliff jumping from 25ft & body surfing on the holy river',
        'Overnight Riverside / Alpine Swiss-tent camping with private bathrooms',
        'Evening bonfire with live acoustic music and Himalayan buffet dinner'
      ],
      inclusions: [
        'All rafting safety gear (CE approved life-jackets, helmets, paddles)',
        'Experienced river guide & safety kayaker support',
        'Meals (Breakfast, Lunch, Evening Snacks & Dinner) at camp',
        'Transport from camp to rafting launch point'
      ]
    },
    'char-dham-yatra': {
      title: 'Char Dham Yatra',
      duration: 'Custom Duration (9-12 Days)',
      category: 'Sacred Pilgrimage',
      description: 'The most sacred pilgrimage in Hinduism across Uttarakhand Devbhoomi: Yamunotri, Gangotri, Kedarnath, and Badrinath. Tailored for families, senior citizens, and groups with verified mountain vehicles and seamless ground coordination.',
      highlights: [
        'Complete pilgrimage circuit covering Yamunotri, Gangotri, Kedarnath & Badrinath',
        'Comfortable sanitized SUVs (Innova Crysta / Ertiga) or 12-26 seater luxury Tempo Travelers',
        'Assistance with biometric Yatra registration, Kedarnath helicopter tickets & pony/doli',
        'Stops at scenic enroute gems: Devprayag sangam, Harsil valley, Rudraprayag & Mana village'
      ],
      inclusions: [
        'Dedicated private mountain vehicle with seasoned Uttarakhand driver',
        'State passenger permit, toll, parking & driver allowance',
        '24/7 ground assistance helpline throughout the high-altitude journey',
        'Flexible pacing tailored to senior pilgrims'
      ]
    },
    'uttarakhand-hill-escape': {
      title: 'Uttarakhand Hill Escape',
      duration: 'Custom Duration (4-6 Days)',
      category: 'Himalayan Hills & Valleys',
      description: 'A restorative escape across the queen of hills Mussoorie, turquoise Tehri Lake water sports, alpine evergreen meadows of Chopta (Mini Switzerland), and historic temple trails.',
      highlights: [
        'Panoramic views of snow-clad peaks from Mussoorie & Dhanaulti eco-parks',
        'Water sports, jet skiing & boating at massive Tehri Dam reservoir',
        'Trek to Tungnath (highest Shiva temple in the world) and Chandrashila peak',
        'Serene homestays and pine-forested valley walks'
      ],
      inclusions: [
        'Private sanitized vehicle for hill transit throughout the tour',
        'Customizable departure dates and custom hotel category options',
        'Driver allowance, night charges & hill permits',
        'Sightseeing as per your preferred custom pace'
      ]
    }
  };

  // Reusable WhatsApp Message Opener
  function openWhatsApp(message) {
    const cleanText = message.trim();
    const encoded = encodeURIComponent(cleanText);
    const waUrl = `https://wa.me/${WHATSAPP_PHONE}?text=${encoded}`;
    window.open(waUrl, '_blank', 'noopener,noreferrer');
  }

  // Toast Notification System
  function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast ${type === 'success' ? 'toast-success' : 'toast-error'}`;
    
    const icon = document.createElement('span');
    icon.className = 'material-symbols-outlined text-[20px]';
    icon.textContent = type === 'success' ? 'check_circle' : 'error';
    
    const text = document.createElement('span');
    text.textContent = message;

    toast.appendChild(icon);
    toast.appendChild(text);
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

  // Phone Number Validator (supports standard 10-digit Indian numbers and formats with +91 / 0)
  function isValidIndianPhone(phone) {
    if (!phone) return false;
    const clean = phone.replace(/[\s\-\(\)]/g, '');
    const regex = /^(\+91|91|0)?[6-9]\d{9}$/;
    return regex.test(clean);
  }

  // Initialize Page Functionality on DOM Ready
  document.addEventListener('DOMContentLoaded', function () {
    // 1. Setup Min Date for all date pickers
    const today = new Date().toISOString().split('T')[0];
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
      input.setAttribute('min', today);
      if (!input.value) {
        input.value = today;
      }
    });

    // 2. Mobile Navigation Drawer Setup
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    const menuIcon = document.getElementById('menu-icon');
    const mobileNavDrawer = document.getElementById('mobile-nav-drawer');
    const mobileNavBackdrop = document.getElementById('mobile-nav-backdrop');
    const mobileNavClose = document.getElementById('mobile-nav-close');
    const mobileNavLinks = document.querySelectorAll('.mobile-nav-link');
    const desktopNavLinks = document.querySelectorAll('#desktop-nav a[href^="#"]');

    function openMobileMenu() {
      if (!mobileNavDrawer || !mobileNavBackdrop) return;
      mobileNavDrawer.classList.add('open');
      mobileNavBackdrop.classList.add('open');
      if (menuIcon) menuIcon.textContent = 'close';
      if (mobileMenuToggle) mobileMenuToggle.setAttribute('aria-expanded', 'true');
      document.body.style.overflow = 'hidden';
    }

    function closeMobileMenu() {
      if (!mobileNavDrawer || !mobileNavBackdrop) return;
      mobileNavDrawer.classList.remove('open');
      mobileNavBackdrop.classList.remove('open');
      if (menuIcon) menuIcon.textContent = 'menu';
      if (mobileMenuToggle) mobileMenuToggle.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    }

    function toggleMobileMenu() {
      if (!mobileNavDrawer) return;
      if (mobileNavDrawer.classList.contains('open')) {
        closeMobileMenu();
      } else {
        openMobileMenu();
      }
    }

    if (mobileMenuToggle) {
      mobileMenuToggle.addEventListener('click', function (e) {
        e.stopPropagation();
        toggleMobileMenu();
      });
    }
    if (mobileNavClose) {
      mobileNavClose.addEventListener('click', function (e) {
        e.stopPropagation();
        closeMobileMenu();
      });
    }
    if (mobileNavBackdrop) {
      mobileNavBackdrop.addEventListener('click', function (e) {
        e.stopPropagation();
        closeMobileMenu();
      });
    }

    // Accurate Header Height Offset for Smooth Scrolling
    function smoothScrollTo(targetSelector) {
      let targetEl;
      if (targetSelector === '#top' || !targetSelector) {
        targetEl = document.body;
      } else {
        targetEl = document.querySelector(targetSelector);
      }
      if (!targetEl) return;

      const header = document.querySelector('header');
      const headerHeight = header ? header.offsetHeight : 85;
      const elementPosition = targetSelector === '#top' ? 0 : targetEl.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = Math.max(0, elementPosition - headerHeight - 10);

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }

    // Mobile Links Click Handler
    mobileNavLinks.forEach(link => {
      link.addEventListener('click', function (e) {
        const target = this.getAttribute('data-target') || this.getAttribute('href');
        if (target && target.startsWith('#')) {
          e.preventDefault();
          closeMobileMenu();
          setTimeout(() => {
            smoothScrollTo(target);
          }, 120);
        }
      });
    });

    // Desktop Links Click Handler
    desktopNavLinks.forEach(link => {
      link.addEventListener('click', function (e) {
        const target = this.getAttribute('href');
        if (target && target.startsWith('#')) {
          e.preventDefault();
          smoothScrollTo(target);
        }
      });
    });

    // Close on Escape Key
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        closeMobileMenu();
        closeLightbox();
        closePackageModal();
      }
    });

    // 3. Header Sticky & Blur Scroll Effect
    const header = document.querySelector('header');
    window.addEventListener('scroll', function () {
      if (window.scrollY > 25) {
        header?.classList.add('header-scrolled');
      } else {
        header?.classList.remove('header-scrolled');
      }
    }, { passive: true });

    // 4. Active Section Spy for both Desktop & Mobile Links
    const navSectionMap = [
      { sectionId: 'hero', navTarget: '#top' },
      { sectionId: 'services', navTarget: '#packages' },
      { sectionId: 'packages', navTarget: '#packages' },
      { sectionId: 'scooter-section', navTarget: '#scooter-section' },
      { sectionId: 'why-choose-us', navTarget: '#destinations-section' },
      { sectionId: 'destinations-section', navTarget: '#destinations-section' },
      { sectionId: 'chardham-section', navTarget: '#chardham-section' },
      { sectionId: 'how-it-works', navTarget: '#packages' },
      { sectionId: 'reviews-section', navTarget: '#reviews-section' },
      { sectionId: 'gallery', navTarget: '#destinations-section' },
      { sectionId: 'about-section', navTarget: '#about-section' },
      { sectionId: 'contact-section', navTarget: '#contact-section' }
    ];

    function updateActiveNav() {
      const scrollPos = window.pageYOffset + 140;
      let currentTarget = '#top';

      for (let i = navSectionMap.length - 1; i >= 0; i--) {
        const el = document.getElementById(navSectionMap[i].sectionId);
        if (el && el.offsetTop <= scrollPos) {
          currentTarget = navSectionMap[i].navTarget;
          break;
        }
      }

      // Update Desktop Nav
      desktopNavLinks.forEach(link => {
        if (link.getAttribute('href') === currentTarget) {
          link.classList.add('active');
          link.classList.add('text-secondary', 'font-bold');
          link.classList.remove('text-on-surface-variant');
        } else {
          link.classList.remove('active');
          link.classList.remove('text-secondary', 'font-bold');
          link.classList.add('text-on-surface-variant');
        }
      });

      // Update Mobile Nav
      mobileNavLinks.forEach(link => {
        const linkTarget = link.getAttribute('data-target') || link.getAttribute('href');
        if (linkTarget === currentTarget) {
          link.classList.add('active');
        } else {
          link.classList.remove('active');
        }
      });
    }

    window.addEventListener('scroll', updateActiveNav, { passive: true });
    updateActiveNav();

    // 5. Quick Booking Hero Tabs Synchronizer
    const enquiryTabs = document.querySelectorAll('#enquiry-tabs .tab-btn');
    const heroServiceSelect = document.getElementById('hero-service-select');

    if (enquiryTabs.length > 0 && heroServiceSelect) {
      enquiryTabs.forEach(tab => {
        tab.addEventListener('click', function () {
          enquiryTabs.forEach(t => {
            t.classList.remove('bg-primary', 'text-on-primary');
            t.classList.add('bg-surface-container', 'text-on-surface-variant');
          });
          this.classList.remove('bg-surface-container', 'text-on-surface-variant');
          this.classList.add('bg-primary', 'text-on-primary');

          const serviceAttr = this.getAttribute('data-service');
          if (serviceAttr) {
            for (let i = 0; i < heroServiceSelect.options.length; i++) {
              if (
                heroServiceSelect.options[i].value.toLowerCase().includes(serviceAttr.toLowerCase()) ||
                serviceAttr.toLowerCase().includes(heroServiceSelect.options[i].value.toLowerCase())
              ) {
                heroServiceSelect.selectedIndex = i;
                break;
              }
            }
          }
        });
      });
    }

    // 6. Quick Booking Hero Form Handler
    const heroBookingForm = document.getElementById('hero-booking-form');
    if (heroBookingForm) {
      heroBookingForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const service = document.getElementById('hero-service-select')?.value || 'Travel Service';
        const date = document.getElementById('hero-date')?.value || '';
        const travelers = document.getElementById('hero-travelers')?.value || '1 Person';
        const nameInput = document.getElementById('hero-name');
        const phoneInput = document.getElementById('hero-phone');

        const name = nameInput?.value.trim() || '';
        const phone = phoneInput?.value.trim() || '';

        // Validation
        let hasError = false;

        if (name.length < 2) {
          nameInput.classList.add('form-input-error');
          showToast('Please enter your full name', 'error');
          hasError = true;
        } else {
          nameInput.classList.remove('form-input-error');
        }

        if (!isValidIndianPhone(phone)) {
          phoneInput.classList.add('form-input-error');
          showToast('Please enter a valid 10-digit mobile number', 'error');
          hasError = true;
        } else {
          phoneInput.classList.remove('form-input-error');
        }

        if (hasError) return;

        // Button Loading State
        const submitBtn = heroBookingForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<span class="material-symbols-outlined text-[18px] animate-spin">refresh</span><span>Connecting...</span>`;

        // Format WhatsApp Message
        const message = `Hello Yog Nagri Tour And Travel,

*New Travel Enquiry*
• *Name:* ${name}
• *Phone:* ${phone}
• *Service:* ${service}
• *Travel Date:* ${date}
• *Travelers:* ${travelers}

Please share availability and best rates.`;

        showToast('Enquiry received! Opening WhatsApp concierge...', 'success');

        setTimeout(() => {
          openWhatsApp(message);
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalText;
        }, 600);
      });
    }

    // 7. Contact Section Form Handler
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
      contactForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const nameInput = document.getElementById('cf-name');
        const phoneInput = document.getElementById('cf-phone');
        const serviceSelect = document.getElementById('cf-service');
        const dateInput = document.getElementById('cf-date');
        const travelersSelect = document.getElementById('cf-travelers');
        const msgInput = document.getElementById('cf-msg');

        const name = nameInput?.value.trim() || '';
        const phone = phoneInput?.value.trim() || '';
        const service = serviceSelect?.value || 'Tour Enquiry';
        const date = dateInput?.value || '';
        const travelers = travelersSelect?.value || '1 Person';
        const msg = msgInput?.value.trim() || 'No specific requests noted.';

        // Validation
        let hasError = false;

        if (name.length < 2) {
          nameInput.classList.add('form-input-error');
          showToast('Please enter your full name', 'error');
          hasError = true;
        } else {
          nameInput.classList.remove('form-input-error');
        }

        if (!isValidIndianPhone(phone)) {
          phoneInput.classList.add('form-input-error');
          showToast('Please enter a valid 10-digit mobile number', 'error');
          hasError = true;
        } else {
          phoneInput.classList.remove('form-input-error');
        }

        if (hasError) return;

        // Button Loading State
        const submitBtn = contactForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<span class="material-symbols-outlined text-[18px] animate-spin">refresh</span><span>Connecting to WhatsApp...</span>`;

        // Format Message
        const message = `Hello Yog Nagri Tour And Travel,

*New Travel Enquiry*
• *Name:* ${name}
• *Phone:* ${phone}
• *Service:* ${service}
• *Travel Date:* ${date}
• *Travelers:* ${travelers}
• *Message / Notes:* ${msg}

Please contact me regarding this enquiry.`;

        showToast('Enquiry validated! Launching WhatsApp...', 'success');

        setTimeout(() => {
          openWhatsApp(message);
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalText;
          contactForm.reset();
          if (dateInput) dateInput.value = today;
        }, 600);
      });
    }

    // 8. Interactive Package Modal Functionality
    const packageModal = document.getElementById('package-modal');
    const modalPackageTitle = document.getElementById('modal-package-title');
    const modalPackageDuration = document.getElementById('modal-package-duration');
    const modalPackageCategory = document.getElementById('modal-package-category');
    const modalPackageDesc = document.getElementById('modal-package-desc');
    const modalPackageHighlights = document.getElementById('modal-package-highlights');
    const modalPackageInclusions = document.getElementById('modal-package-inclusions');
    const modalPackageCta = document.getElementById('modal-package-cta');
    const modalCloseBtn = document.getElementById('modal-package-close');

    function openPackageModal(packageKey) {
      const data = PACKAGES_DATA[packageKey];
      if (!data || !packageModal) return;

      modalPackageTitle.textContent = data.title;
      modalPackageDuration.textContent = data.duration;
      modalPackageCategory.textContent = data.category;
      modalPackageDesc.textContent = data.description;

      modalPackageHighlights.innerHTML = data.highlights
        .map(h => `<li class="flex items-start gap-2 text-on-surface-variant text-body-sm"><span class="material-symbols-outlined text-secondary text-[18px] shrink-0 mt-0.5">check_circle</span><span>${h}</span></li>`)
        .join('');

      modalPackageInclusions.innerHTML = data.inclusions
        .map(inc => `<li class="flex items-start gap-2 text-on-surface-variant text-body-sm"><span class="material-symbols-outlined text-on-tertiary-container text-[18px] shrink-0 mt-0.5">verified</span><span>${inc}</span></li>`)
        .join('');

      modalPackageCta.onclick = function () {
        const msg = `Hello Yog Nagri Tour And Travel, I want to enquire about the ${data.title} (${data.duration}) package. Please share details and best quote.`;
        openWhatsApp(msg);
      };

      packageModal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }

    function closePackageModal() {
      if (!packageModal) return;
      packageModal.classList.remove('active');
      document.body.style.overflow = '';
    }

    if (modalCloseBtn) {
      modalCloseBtn.addEventListener('click', closePackageModal);
    }
    if (packageModal) {
      packageModal.addEventListener('click', function (e) {
        if (e.target === packageModal) {
          closePackageModal();
        }
      });
    }

    // Attach click listeners to "View Package" / Package card buttons
    const packageButtons = document.querySelectorAll('[data-package-trigger]');
    packageButtons.forEach(btn => {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        const packageKey = this.getAttribute('data-package-trigger');
        if (packageKey) {
          openPackageModal(packageKey);
        }
      });
    });

    // 9. Interactive Gallery Lightbox
    const lightboxModal = document.getElementById('lightbox-modal');
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxCaption = document.getElementById('lightbox-caption');
    const lightboxClose = document.getElementById('lightbox-close');
    const galleryItems = document.querySelectorAll('[data-lightbox-src]');

    function openLightbox(src, caption) {
      if (!lightboxModal || !lightboxImg) return;
      lightboxImg.src = src;
      lightboxCaption.textContent = caption || 'Yog Nagri Tour & Travel Moments';
      lightboxModal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }

    function closeLightbox() {
      if (!lightboxModal) return;
      lightboxModal.classList.remove('active');
      document.body.style.overflow = '';
    }

    galleryItems.forEach(item => {
      item.addEventListener('click', function () {
        const src = this.getAttribute('data-lightbox-src') || this.querySelector('img')?.src;
        const caption = this.getAttribute('data-lightbox-caption') || this.querySelector('div')?.textContent || '';
        if (src) {
          openLightbox(src, caption);
        }
      });
    });

    if (lightboxClose) {
      lightboxClose.addEventListener('click', closeLightbox);
    }
    if (lightboxModal) {
      lightboxModal.addEventListener('click', function (e) {
        if (e.target === lightboxModal || e.target.classList.contains('lightbox-content')) {
          closeLightbox();
        }
      });
    }

    // 10. Direct WhatsApp Trigger Buttons
    const whatsappTriggers = document.querySelectorAll('[data-whatsapp-msg]');
    whatsappTriggers.forEach(el => {
      el.addEventListener('click', function (e) {
        e.preventDefault();
        const message = this.getAttribute('data-whatsapp-msg');
        if (message) {
          openWhatsApp(message);
        }
      });
    });

    // 11. Image Error Fallback Handler
    // In case any remote image fails to load, gracefully substitute with verified travel imagery
    const FALLBACK_IMAGES = {
      hero: 'https://images.unsplash.com/photo-1600680489240-547043818e61?auto=format&fit=crop&w=1600&q=80',
      scooter: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=800&q=80',
      temple: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&w=800&q=80',
      river: 'https://images.unsplash.com/photo-1596895111956-bf1cf0599ce5?auto=format&fit=crop&w=800&q=80',
      rafting: 'https://images.unsplash.com/photo-1530866495561-507c9faab2ed?auto=format&fit=crop&w=800&q=80',
      mountains: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80'
    };

    document.querySelectorAll('img').forEach(img => {
      img.addEventListener('error', function () {
        const alt = (this.getAttribute('alt') || '').toLowerCase();
        if (alt.includes('scooter') || alt.includes('bike')) {
          this.src = FALLBACK_IMAGES.scooter;
        } else if (alt.includes('temple') || alt.includes('kedarnath') || alt.includes('aarti')) {
          this.src = FALLBACK_IMAGES.temple;
        } else if (alt.includes('rafting')) {
          this.src = FALLBACK_IMAGES.rafting;
        } else if (alt.includes('mountain') || alt.includes('himalaya') || alt.includes('chopta')) {
          this.src = FALLBACK_IMAGES.mountains;
        } else {
          this.src = FALLBACK_IMAGES.river;
        }
      });
    });

    // 12. Expose Globals for Inline Calls if Needed
    window.YogNagri = {
      openWhatsApp,
      showToast,
      openPackageModal,
      closePackageModal
    };
  });
})();
