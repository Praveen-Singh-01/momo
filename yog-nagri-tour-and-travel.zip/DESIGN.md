---
name: Yog Nagri Odyssey
colors:
  surface: '#fbf9f5'
  surface-dim: '#dbdad6'
  surface-bright: '#fbf9f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ef'
  surface-container: '#efeeea'
  surface-container-high: '#eae8e4'
  surface-container-highest: '#e4e2de'
  on-surface: '#1b1c1a'
  on-surface-variant: '#44474e'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f0ed'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#495f82'
  primary: '#001026'
  on-primary: '#ffffff'
  primary-container: '#0b2545'
  on-primary-container: '#778db2'
  inverse-primary: '#b1c7f0'
  secondary: '#006a63'
  on-secondary: '#ffffff'
  secondary-container: '#99efe5'
  on-secondary-container: '#006f67'
  tertiary: '#1e0b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#3c1d00'
  on-tertiary-container: '#d47300'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d5e3ff'
  primary-fixed-dim: '#b1c7f0'
  on-primary-fixed: '#001c3b'
  on-primary-fixed-variant: '#314769'
  secondary-fixed: '#9cf2e8'
  secondary-fixed-dim: '#80d5cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#00504a'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#fbf9f5'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2de'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 38px
    fontWeight: '700'
    lineHeight: 46px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system embodies a balanced synthesis of spiritual tranquility and alpine expedition. Designed for travelers seeking pilgrimages, wellness retreats, white-water rafting, and Himalayan treks across Uttarakhand, the UI projects reverence, local authenticity, and contemporary luxury.

### Emotional Tone & Aesthetics
- **Serene & Elevated:** Evokes the sacred stillness of the morning Ganges mist combined with the structural clarity of premier modern eco-resorts.
- **Adventurous & Reliable:** Instills safety and uncompromised local competence through crisp information architecture, verified credentials, and high-legibility typographic hierarchies.
- **Subtle Glassmorphic Tactility:** Layered translucent surfaces mimic crystalline river waters and mountain fog, accented by the warmth of marigold ceremonial offerings.

### Design Movements
A hybrid of **Modern Editorial Minimalism** and **Organic Glassmorphism**. Layouts feature spacious editorial compositions, delicate translucent containers with light inner borders, subtle glowing saffron interactive elements, and crisp high-conversion affordances tailored for immediate mobile actions (direct WhatsApp concierge and live itinerary bookings).

## Colors

The palette draws directly from the geographic and cultural landscape of Rishikesh: the deep indigo shadows of the Shivalik foothills, the emerald rush of the glacial Ganges, and the sacred marigold saffron of evening Ganga Aarti ceremonies.

### Color Roles & Implementation
- **Primary (`#0B2545` - Himalayan Navy):** Anchor color for high-emphasis headings, key navigation bars, solid prominent badges, and deeply grounded footer architectures. Communicates institutional authority, nighttime mountain silhouettes, and safety.
- **Secondary (`#0F766E` - River Emerald):** Applied to success states, environmental badges, eco-trek filters, trust verifications, and tranquil subheaders. Represents rejuvenation and life along the riverbed.
- **Tertiary (`#D97706` - Saffron Gold):** High-conversion accent reserved for primary action triggers (e.g., "Book Your Yatra", "Chat on WhatsApp"), price callouts, review star metrics, and critical alert highlights. Emits an inviting, warm luminescence.
- **Neutral Surface Palette:**
  - Base Background: `#FBF9F5` (Alpine Mist / Warm Canvas) prevents sterile glare, establishing an inviting, tactile earthiness.
  - Surface Containers: `#FFFFFF` with varying levels of opacity (`rgba(255, 255, 255, 0.82)`) for frosted glass overlays.
  - Subtle Borders & Dividers: `#E7E0D6` (River Stone).
- **Text Hierarchy:**
  - High Emphasis: `#1E293B` (Slate Night).
  - Medium Emphasis: `#475569` (Muted Slate).
  - Low Emphasis: `#94A3B8` (Mist Gray).

## Typography

The typographic pairing reflects both the classical literary lineage of Uttarakhand and clean, accessible digital utility.

### Pairing Strategy
- **Display & Section Headlines (`Playfair Display`):** Brings editorial poise, timeless beauty, and deliberate prestige to tour names, experiential titles, and narrative pull quotes. Harmonizes naturally with classical Devanagari headline styles.
- **Functional Body & Interfaces (`Plus Jakarta Sans`):** Provides pristine legibility across mobile screens, booking engines, metadata lists, and itineraries. Its humanist geometry mirrors soft modernism while ensuring high readability at compact sizes.
- **Bilingual & Devanagari Coexistence:** For Hindi copy segments (e.g., "योग नगरी टूर एंड ट्रैवल"), pair with `Noto Sans Devanagari` matching font weights and baseline optical heights against `Plus Jakarta Sans` to maintain rhythm without visual clipping.

### Rules of Usage
- Display headers must never exceed 3 lines on mobile viewports.
- All pricing metrics and duration chips use `label-lg` or `headline-sm` set in `Plus Jakarta Sans` with tabular numeric spacing to guarantee clean data alignment.
- Uppercase styling is reserved strictly for `label-sm` category qualifiers, badge tags, and breadcrumb markers.

## Layout & Spacing

The layout is structured on a responsive 12-column fluid grid on desktop viewports and a 4-column fluid layout on mobile devices.

### Grid & Breakpoints
- **Mobile (`< 768px`):** 4 columns, `margin-mobile` of `1.25rem`, `gutter-mobile` of `1rem`. Itinerary cards and quick-booking bars span full width, with horizonal carousels extending edge-to-edge via negative bleed.
- **Tablet (`768px - 1024px`):** 8 columns, `2rem` margins, `1.25rem` gutters. Package cards shift to dual-column structures with side-sheet preview drawers.
- **Desktop (`> 1024px`):** 12 columns, max-width constrained to `1280px` centered within a `margin` of `3rem`, `gutter` of `1.5rem`. Enables 3-column tour package grids and 2-column editorial itineraries with sticky checkout/inquiry sidebars.

### Vertical Rhythm
- Section spacing follows an expanded `space-xl` progression (`4rem` to `6rem` vertical margins) to maintain meditative spaciousness.
- Compact component grouping uses `space-xs` and `space-sm` for immediate relation between icons, ratings, and copy lines.

## Elevation & Depth

Visual hierarchy uses luminous atmospheric depth rather than heavy synthetic drop shadows, recalling light shifting through Himalayan valleys.

### Layering Principles
- **Ground (`0dp`):** Canvas backdrop `#FBF9F5` establishing an organic, glare-free foundation.
- **Elevated Cards (`1dp`):** Pure `#FFFFFF` surfaces with an ultra-soft dual shadow: `0 4px 20px -2px rgba(11, 37, 69, 0.05), 0 2px 6px -1px rgba(11, 37, 69, 0.03)` with a hairline border `1px solid rgba(231, 224, 214, 0.6)`.
- **Glassmorphic Floating Navigation & Modals (`2dp`):** Frosted panels using `background: rgba(255, 255, 255, 0.88)`, `backdrop-filter: blur(12px)`, and a subtle top specular stroke `1px solid rgba(255, 255, 255, 0.6)`. Shadow: `0 12px 32px -4px rgba(11, 37, 69, 0.08)`.
- **Conversion CTA Highlights (`Floating Active`):** Warm Saffron buttons carry a soft, tinted underglow: `0 4px 14px 0 rgba(217, 119, 6, 0.35)`.

## Shapes

The interface adopts a refined, balanced geometric curvature (`roundedness: 2`).

### Corner Radius Standards
- **Standard (`0.5rem / 8px`):** Used on input elements, dropdown selects, and data table segments.
- **Large (`1rem / 16px`):** Standard for travel package cards, itinerary timelines, testimonial tiles, and hero image frames.
- **Extra Large (`1.5rem / 24px`):** Applied to floating booking docks, bottom sheets, and promotional hero banners.
- **Full / Pill:** Applied to status badges, category filter chips, verified check marks, rating pills, and high-conversion floating WhatsApp CTA buttons.

## Components

### Buttons & Action Bars
- **Primary CTA ("Book Yatra / Instant Quote"):** Solid `#D97706` background with `#FFFFFF` text, bold weight (`label-lg`), pill-rounded or `0.5rem` radius, accented with the warm amber glow shadow. On hover, shifts to `#B45309` with an interactive elevation lift of `1px`.
- **Secondary CTA ("Explore Itinerary"):** Translucent `#0F766E` tint (`rgba(15, 118, 110, 0.08)`), text `#0F766E`, border `1px solid rgba(15, 118, 110, 0.2)`.
- **WhatsApp Concierge Floating Button:** Fixed bottom-right action anchored in `#10B981` (or `#25D366`), pill radius, containing official messaging icon + "Chat with Local Guide" label, accompanied by ambient shadow `0 8px 24px rgba(16, 185, 129, 0.3)`.

### Cards & Package Modules
- **Tour Package Card:** Top image frame with a fixed aspect ratio (16:10), inner border radius `1rem`. Houses a top-left floating pill badge for trip type (e.g., "Spiritual Yatra", "River Expedition") and a top-right frosted glass price pill (`₹ / person`). Card body holds `title-lg` tour name, star rating with review count, key spec icons (duration, altitude, vehicle type), and dual direct action buttons ("Call Now" and "Book").
- **Trust & Verification Badges:** Minimalist horizontal cards displaying "4.8/5 Star Rated", "Uttarakhand Tourism Approved", and "24/7 Ground Assistance" supported by subtle `#0F766E` emerald accents.

### Chips & Filter Tags
- **Filter Chips:** Default state `#FFFFFF` with `1px solid #E7E0D6` border, text `#475569`. Active state shifts to `#0B2545` solid background with `#FFFFFF` text. Pill-shaped (`rounded-full`) with `space-sm` vertical and `space-md` horizontal padding.

### Form Inputs & Search Bar
- **Hero Booking Search Bar:** Glassmorphic container containing modular segmented inputs (Destination, Date Range, Travel Style, Guests). Inputs have zero border individually, separated by hairline vertical rules (`#E7E0D6`), resolving into an integrated primary gold search button.
- **Standard Input Fields:** Height `48px`, background `#FFFFFF`, border `1px solid #CBD5E1`, text `#1E293B`, focus ring `2px solid #0F766E` with zero offset.

### Itinerary Timeline & Lists
- **Spiritual / Adventure Timelines:** Connected vertical line in `#0F766E` with hollow circular day nodes (`Day 01`, `Day 02`). Nodes highlight key spiritual rituals (e.g., "Triveni Ghat Aarti at 6:00 PM") with warm marigold badges.